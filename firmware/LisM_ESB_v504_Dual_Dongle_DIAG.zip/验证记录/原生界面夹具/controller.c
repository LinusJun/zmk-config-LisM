/* Real controller and real device-page LVGL, with modeled button/PWM/battery I/O. */
#include <stdint.h>
#include <stdbool.h>
#define main devices_main
#include "main.c"
#undef main
#define CLAMP(v,a,b) ((v)<(a)?(a):(v)>(b)?(b):(v))
#define INPUT_EV_KEY 1
#define INPUT_BTN_1 257
#define DEVICE_DT_GET(n) (&fake_device)
#define DEVICE_DT_GET_ONE(n) (&fake_device)
#define DT_NODELABEL(n) 0
#define DT_NODE_CHILD_IDX(n) 0
#define INPUT_CALLBACK_DEFINE(...)
struct device {int x;};static struct device fake_device;static uint32_t now=1000;static int backlight;
struct input_event{unsigned type,code,value;};
static uint32_t k_uptime_get_32(void){return now;}
static bool device_is_ready(const struct device*d){(void)d;return true;}
static int led_set_brightness(const struct device*d,int led,unsigned value){(void)d;assert(!led&&value<=100);backlight=value;return 0;}
static uint8_t zmk_battery_state_of_charge(void){return 83;}
static bool zmk_usb_is_powered(void){return true;}
#include "../source/src/kb_route/layer_label.h"
#include "controller_ui.inc"
static void sample(uint8_t f,uint16_t x,uint16_t y){xiao147_ui_touch(f,x,y,XIAO147_USB_LEFT);}
static void commit_input(void){bool active;if(lism_screen_take_request(&active))lism_screen_commit(active);}
#include "actual_home.inc"
bool kb_esb_signal(unsigned source,int8_t*d){*d=source?-63:-49;return true;}
bool lism_input_host_signal(int8_t*d){*d=-69;return fixture.enabled;}

static void memory(const char*stage){lv_mem_monitor_t m;lv_mem_monitor(&m);printf("MEM %s free=%zu largest=%zu max_used=%zu\n",stage,m.free_size,m.free_biggest_size,m.max_used);fflush(stdout);}

static void geometry(void){
 lv_obj_update_layout(screen);lv_area_t a;lv_obj_get_coords(home_mod.obj,&a);assert(a.x1==4&&a.x2==315);
 lv_obj_get_coords(home_wpm.obj,&a);assert(a.x1==4&&a.x2==315);
 lv_obj_get_coords(home_layer.obj,&a);assert(a.x1==4&&a.x2==315);
 lv_obj_get_coords(home_output.obj,&a);assert(a.x1==144&&a.x2==315);
 assert(lv_obj_get_child_count(home_output.obj)==7); /* USB/BLE and five slots */
 for(unsigned i=0;i<7;i++){lv_obj_t*o=lv_obj_get_child(home_output.obj,i);lv_obj_get_coords(o,&a);assert(a.x1>=144&&a.x2<=315&&a.y2<172);}
 lv_obj_get_coords(signal_icons,&a);assert(a.x1==4&&a.y1==70&&lv_area_get_height(&a)==23);
 assert(lv_obj_get_child_count(screen)==7); /* five groups, mode and signal; no local battery */
}
int main(int argc,char**argv){
 assert(argc==3);unsigned scenario=atoi(argv[1]);lv_init();lv_display_t*d=lv_display_create(320,172);static uint8_t buffer[320*32*2];
 lv_display_set_color_format(d,LV_COLOR_FORMAT_RGB565);lv_display_set_buffers(d,buffer,NULL,sizeof(buffer),LV_DISPLAY_RENDER_MODE_PARTIAL);lv_display_set_flush_cb(d,flush);
 lv_obj_t*s=lv_screen_active();lv_obj_set_style_pad_all(s,0,0);lv_obj_set_style_bg_color(s,lv_color_black(),0);populate();actual_home(s);lism_screen_create(s);xiao147_ui_start(s);refresh(NULL);lv_obj_update_layout(s);memory("home");geometry();
 if(scenario==9){
  assert(XIAO147_PAGE_COUNT==2&&backlight==100&&!xiao147_ui_is_sleeping());memory("test start");
  unsigned pg=xiao147_ui_pointer_generation();xiao147_ui_next_page();refresh(NULL);
  assert(xiao147_ui_page()==0&&!lism_screen_active()); /* wait for real input release commit */
  commit_input();refresh(NULL);assert(xiao147_ui_page()==1&&lism_screen_active()&&root);
  assert(xiao147_ui_pointer_generation()!=pg);memory("devices");
  focus=2;action(37);poll(NULL);assert(fixture.enabled);focus=0;action(37);poll(NULL);tick();memory("search");
  fixture.seconds_left=29;poll(NULL);assert(strstr(lv_label_get_text(status_label),"29s"));
  focus=0;action(37);render();tick();memory("connect dialog");
  for(unsigned auth=1;auth<=3;auth++){fixture.auth_type=auth;fixture.auth_token=100+auth;fixture.passkey=123456;poll(NULL);tick();memory("pairing dialog");}
  fixture.auth_type=0;dialog=NONE;view=DEVICES;poll(NULL);render();
  /* A page cancel invalidates all previously queued contacts. */
  unsigned before=searches;sample(1,20,40);sample(0,0,0);sample(255,0,0);refresh(NULL);assert(searches==before);
  lism_screen_commit(false);refresh(NULL);assert(xiao147_ui_page()==0&&!root);geometry();
  lv_mem_monitor_t before_mem,after;lv_mem_monitor(&before_mem);
  for(unsigned i=0;i<40;i++){
   xiao147_ui_next_page();refresh(NULL);commit_input();refresh(NULL);assert(xiao147_ui_page()==1);
   xiao147_ui_next_page();refresh(NULL);commit_input();refresh(NULL);assert(xiao147_ui_page()==0);
  }
  assert(!root);lv_mem_monitor(&after);assert(after.free_size+256>=before_mem.free_size);geometry();memory("after 40 two-page cycles");
  now+=3600000;refresh(NULL);assert(backlight==100&&!xiao147_ui_is_sleeping()&&!xiao147_ui_wake_on_touch());
  printf("PASS actual XIAO controller/LVGL: 2 pages, async input release, native 312px width, five profiles, no local power widgets, fixed 100%%/no sleep, 40 two-page cycles free=%zu -> %zu\n",before_mem.free_size,after.free_size);return 0;
 }
 if(scenario==3){kb_layer_label_update(home_wpm.layer_label,"GAMEJOYSTICK");}
 if(scenario==4){fixture.enabled=true;fixture.peers[0]=(struct lism_input_peer_status){.saved=true,.connected=true,.ready=true,.type=LISM_INPUT_DEVICE_TOUCHPAD};strcpy(fixture.peers[0].name,"CheerPod2");icon_refresh(NULL);}
 if(scenario==1 || scenario==2 || scenario==4){xiao147_ui_next_page();refresh(NULL);commit_input();refresh(NULL);}
 tick();lv_obj_update_layout(s);
 if(scenario==3){lv_area_t sig,name,meter;lv_obj_get_coords(signal_icons,&sig);lv_obj_get_coords(home_wpm.layer_label,&name);lv_obj_get_coords(home_wpm.obj,&meter);assert(name.x1>sig.x2&&name.x2<=meter.x2&&name.y2<=meter.y2);assert(!strcmp(lv_label_get_text(home_wpm.layer_label),"JOYSTICK"));}
 FILE*f=fopen(argv[2],"wb");assert(f);fwrite(pixels,1,sizeof(pixels),f);fclose(f);return 0;
}
