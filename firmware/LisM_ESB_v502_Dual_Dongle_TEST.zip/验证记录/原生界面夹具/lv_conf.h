#define LV_COLOR_DEPTH 16
#ifndef LV_MEM_SIZE
#define LV_MEM_SIZE (96 * 1024U)
#endif
#define LV_USE_OS LV_OS_NONE
#define LV_FONT_MONTSERRAT_10 1
#define LV_FONT_MONTSERRAT_12 1
#define LV_FONT_MONTSERRAT_14 1
#define LV_FONT_MONTSERRAT_18 1
#define LV_USE_LOG 1
#define LV_LOG_LEVEL LV_LOG_LEVEL_WARN
#define LV_USE_ASSERT_MALLOC 1
#define LV_CONF_H
#include <stdlib.h>
#define LV_ASSERT_HANDLER abort();
