#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <lvgl.h>
#include "../source/src/lism_screen.c"
static struct lism_input_status fixture;
static unsigned searches,cancels,selects,retries,forgets,auths,last_slot,last_index;
static uint32_t last_token,last_passkey;
static bool last_filter,last_accept;
bool lism_input_host_enabled(void){return fixture.enabled;}
void lism_input_host_set_enabled(bool enabled){fixture.enabled=enabled;}
void lism_input_host_snapshot(struct lism_input_status *out){*out=fixture;}
void lism_input_host_search(uint8_t s,bool all){searches++;last_slot=s;last_filter=all;fixture.selected=s;fixture.searching=true;}
void lism_input_host_cancel(void){cancels++;fixture.searching=false;}
void lism_input_host_select(uint8_t i,uint32_t t){selects++;last_index=i;last_token=t;}
void lism_input_host_forget(uint8_t s){forgets++;last_slot=s;}
void lism_input_host_retry(uint8_t s){retries++;last_slot=s;}
void lism_input_host_auth(uint32_t t,bool a,uint32_t p){auths++;last_token=t;last_accept=a;last_passkey=p;}
static unsigned char pixels[320*172*2];
static void flush(lv_display_t *display,const lv_area_t *a,uint8_t *map){
 for(int y=a->y1;y<=a->y2;y++)for(int x=a->x1;x<=a->x2;x++){
  unsigned src=((y-a->y1)*(a->x2-a->x1+1)+(x-a->x1))*2,dst=(y*320+x)*2;
  pixels[dst]=map[src];pixels[dst+1]=map[src+1];
 }
 lv_display_flush_ready(display);
}
static void populate(void){
 fixture=(struct lism_input_status){0};
 fixture.candidates[0]=(struct lism_hid_candidate){.valid=true,.token=11,.rssi=-43};
 strcpy(fixture.candidates[0].name,"CheerPod2");strcpy(fixture.candidates[0].address,"A4:C1:38:7B:20:19");
 fixture.candidates[1]=(struct lism_hid_candidate){.valid=true,.token=22,.rssi=-56};
 strcpy(fixture.candidates[1].name,"BLE Keyboard");strcpy(fixture.candidates[1].address,"20:16:03:11:25:0A");
}
static void tick(void){for(int i=0;i<4;i++){lv_tick_inc(50);lv_timer_handler();}}
static void test_ui(lv_obj_t *screen){
 /* No device page objects allocated at boot. */
 lism_screen_commit(false);poll(NULL);assert(!root);
 for(unsigned i=0;i<36;i++)lv_obj_create(screen); /* home children beyond bit31 */
 unsigned initial=lv_obj_get_child_count(screen);
 lv_obj_t *home=lv_obj_create(screen),*hidden=lv_obj_create(screen);lv_obj_add_flag(hidden,LV_OBJ_FLAG_HIDDEN);
 lism_screen_commit(true);poll(NULL);assert(root && lv_obj_has_flag(home,LV_OBJ_FLAG_HIDDEN));
 assert(!fixture.enabled && focus==2 && !selectable(0) && !selectable(1));
 lv_obj_update_layout(screen);lism_screen_touch(1,30,130);lism_screen_touch(0,0,0);assert(fixture.enabled && !searches);poll(NULL);
 focus=0;action(37);assert(searches==1 && !last_filter && view==SEARCH); /* original HID-only default */
 fixture.searching=true;fixture.selected=0;poll(NULL);focus=0;action(37);assert(dialog==CONNECT);
 unsigned before_cancel=cancels;action(37);assert(dialog==NONE && view==SEARCH && cancels==before_cancel); /* close popup only */
 focus=0;action(37);fixture.candidates[0].token=99;strcpy(fixture.candidates[0].address,"AA:00:00:00:00:99");
 action(45);action(37);assert(!selects && dialog==NONE); /* immutable candidate identity */
 poll(NULL);focus=0;action(37);action(45);action(37);assert(selects==1 && last_token==99 && last_index==0 && view==DEVICES);
 fixture.peers[0].saved=true;fixture.peers[0].legacy_token=100;strcpy(fixture.peers[0].name,"Same name");
 poll(NULL);focus=0;action(37);assert(dialog==DEVICE);choice=0;fixture.peers[0].legacy_token=101;
 action(37);assert(!retries && dialog==NONE); /* menu cannot target a replaced same-name peer */
 /* A hidden Retry can never retain focus after asynchronous reconnection. */
 poll(NULL);focus=0;action(37);choice=0;fixture.peers[0].ready=true;poll(NULL);assert(choice==2);
 action(37);assert(!retries && dialog==NONE);
 fixture.peers[0].ready=false;poll(NULL);focus=0;action(37);choice=0;fixture.peers[0].ready=true;
 action(37);assert(!retries && dialog==NONE); /* even before the next render */
 poll(NULL);focus=0;action(37);choice=1;action(37);assert(dialog==FORGET && choice==1);
 action(37);assert(!forgets); /* Cancel is default */
 focus=0;action(37);choice=1;action(37);choice=0;action(37);assert(forgets==1 && last_slot==0);
 fixture.auth_type=LISM_INPUT_AUTH_ENTRY;fixture.auth_token=123;poll(NULL);assert(modal);
 for(unsigned i=0;i<6;i++)pin[i]=i+1;pin_cursor=6;action(37);
 assert(auths==1 && last_accept && last_token==123 && last_passkey==123456);
 fixture.auth_type=LISM_INPUT_AUTH_NONE;memset(fixture.candidates,0,sizeof(fixture.candidates));view=SEARCH;page=3;focus=0;shown=fixture;normalize_focus();assert(focus==3); /* no hidden-row focus */
 focus=3;action(37);assert(view==DEVICES && cancels==before_cancel+1);
 fixture.enabled=false;poll(NULL);focus=0;action(37);assert(dialog==DEVICE);
 choice=0;render_modal();assert(choice==2);action(37);assert(dialog==NONE && !retries);
 focus=2;action(37);assert(fixture.enabled && fixture.peers[0].saved);poll(NULL);
 /* Touch cancel/move cannot re-arm within a contact, and stale rows are inert. */
 fixture.auth_type=0;view=DEVICES;dialog=NONE;fixture.peers[0].saved=false;fixture.peers[0].ready=false;fixture.peers[0].connected=false;shown=fixture;layout=-1;render();lv_obj_update_layout(screen);
 unsigned before_search=searches;
 lism_screen_touch(1,20,40);lism_screen_touch(1,200,140);lism_screen_touch(1,20,40);lism_screen_touch(0,0,0);assert(searches==before_search);
 lism_screen_touch(255,0,0);lism_screen_touch(1,20,40);lism_screen_touch(0,0,0);assert(searches==before_search);
 lism_screen_touch(1,20,40);fixture.peers[0].saved=true;strcpy(fixture.peers[0].name,"replacement");lism_screen_touch(0,0,0);assert(searches==before_search);
 poll(NULL);fixture.peers[0].saved=false;poll(NULL);lv_obj_update_layout(screen);lism_screen_touch(1,20,40);lism_screen_touch(0,0,0);assert(searches==before_search+1);
 view=DEVICES;dialog=NONE;shown=fixture;render();

 /* Changing unrelated RSSI/countdown/peer text during a tap must not swallow it. */
 fixture.enabled=false;fixture.peers[0]=(struct lism_input_peer_status){0};view=DEVICES;dialog=NONE;shown=fixture;render();lv_obj_update_layout(screen);
 lism_screen_touch(1,30,130);fixture.candidates[0].rssi--;fixture.generation++;poll(NULL);lism_screen_touch(0,0,0);assert(fixture.enabled);poll(NULL);
 unsigned old_searches=searches;
 lism_screen_touch(1,20,40);strcpy(fixture.peers[1].message,"background update");fixture.generation++;poll(NULL);lism_screen_touch(0,0,0);assert(searches==old_searches+1&&view==SEARCH);
 fixture.candidates[0].valid=true;fixture.candidates[0].token=771;strcpy(fixture.candidates[0].address,"01:02:03:04:05:06");strcpy(fixture.candidates[0].name,"CheerPod2");fixture.seconds_left=30;fixture.searching=true;poll(NULL);lv_obj_update_layout(screen);
 lism_screen_touch(1,20,40);fixture.seconds_left=29;fixture.candidates[0].rssi--;poll(NULL);lism_screen_touch(0,0,0);assert(dialog==CONNECT);
 dialog=NONE;render();lv_obj_update_layout(screen);lism_screen_touch(1,20,40);fixture.candidates[0].token++;poll(NULL);lism_screen_touch(0,0,0);assert(dialog==NONE);
 /* Replacing an auth prompt while OK is down must never confirm the new one. */
 fixture.auth_type=LISM_INPUT_AUTH_CONFIRM;fixture.auth_token=900;poll(NULL);lv_obj_update_layout(screen);unsigned old_auths=auths;
 lism_screen_touch(1,275,154);fixture.auth_token++;poll(NULL);lism_screen_touch(0,0,0);assert(auths==old_auths);
 fixture.auth_type=0;dialog=NONE;view=DEVICES;poll(NULL);render();
 lv_mem_monitor_t baseline={0},after={0};
 for(unsigned i=0;i<25;i++){
  lism_screen_commit(false);poll(NULL);tick();assert(!root && !modal);
  assert(lv_obj_get_child_count(screen)==initial+2 && !lv_obj_has_flag(home,LV_OBJ_FLAG_HIDDEN) && lv_obj_has_flag(hidden,LV_OBJ_FLAG_HIDDEN));
  if(i==4)lv_mem_monitor(&baseline);
  if(i==24)lv_mem_monitor(&after);
  lism_screen_commit(true);poll(NULL);dialog=DEVICE;choice=2;render();tick();
 }
 assert(after.free_size+256>=baseline.free_size);
 printf("PASS actual LVGL UI: candidate/slot identity, safe defaults, HID-only, PIN, hidden focus, 25 reopen/close cycles, free=%zu -> %zu\n",baseline.free_size,after.free_size);
}
int main(int argc,char**argv){
 assert(argc==3);unsigned scenario=atoi(argv[1]);lv_init();
 lv_display_t *display=lv_display_create(320,172);static uint8_t buffer[280*40*2];
 lv_display_set_color_format(display,LV_COLOR_FORMAT_RGB565);lv_display_set_buffers(display,buffer,NULL,sizeof(buffer),LV_DISPLAY_RENDER_MODE_PARTIAL);
 lv_display_set_flush_cb(display,flush);lv_obj_t *screen=lv_screen_active();lv_obj_set_style_pad_all(screen,0,0);
 populate();if(scenario!=9 && scenario!=6)fixture.enabled=true;lism_screen_create(screen);
 if(scenario==9){test_ui(screen);return 0;}
 if(scenario==1 || scenario==3){
  for(unsigned i=0;i<2;i++){fixture.peers[i].saved=fixture.peers[i].ready=fixture.peers[i].connected=true;fixture.peers[i].legacy_token=30+i;strcpy(fixture.peers[i].name,i?"BLE Keyboard":"CheerPod2");}
 }
 if(scenario==2 || scenario==5){fixture.auth_type=scenario==2?LISM_INPUT_AUTH_CONFIRM:LISM_INPUT_AUTH_ENTRY;fixture.auth_token=10;fixture.passkey=123456;}
 lism_screen_commit(true);poll(NULL);
 if(scenario==0){view=SEARCH;fixture.searching=true;shown=fixture;focus=0;render();}
 if(scenario==3){dialog=DEVICE;slot=0;strcpy(peer_name,fixture.peers[0].name);peer_token=fixture.peers[0].legacy_token;choice=2;render();}
 if(scenario==4){view=SEARCH;dialog=CONNECT;chosen=fixture.candidates[0];choice=1;render();}
 if(scenario==5){for(unsigned i=0;i<6;i++)pin[i]=i+1;pin_cursor=5;render();}
 tick();FILE*f=fopen(argv[2],"wb");assert(f);fwrite(pixels,1,sizeof(pixels),f);fclose(f);
 lv_mem_monitor_t m;lv_mem_monitor(&m);printf("preview64bit allocated=%zu free=%zu\n",m.total_size-m.free_size,m.free_size);
 return 0;
}
