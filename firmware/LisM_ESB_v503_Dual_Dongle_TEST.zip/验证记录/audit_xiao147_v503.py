from pathlib import Path
import json,subprocess,hashlib,sys
from elftools.elf.elffile import ELFFile
P=Path('/work');S=P/'source';W=P/'workspace';V=P/'verification'
sys.path.insert(0,str(S/'tools'));from build_upstream_esb import production_fingerprint
fp,_=production_fingerprint();previous='dcfbcfdfa9c9ee0cef4f8df20898027b9a30429d'
allowed={'src/lism_screen.c','tools/build_upstream_esb.py'}
production=[]
for folder in ['src','config','boards','dts','cmake','zephyr','tools']:
 production+=subprocess.check_output(['git','-C',str(S),'ls-tree','-r','--name-only',previous,'--',folder],text=True).splitlines()
production+=['Kconfig','CMakeLists.txt']
changed=[]
for name in production:
 old=subprocess.check_output(['git','-C',str(S),'show',previous+':'+name])
 if (S/name).read_bytes()!=old:changed.append(name);assert name in allowed,name
assert set(changed)==allowed,changed
rows={}
for t in ['left','right','dongle_a','dongle_b','reset']:
 r=json.loads((S/f'artifacts/{t}-build.json').read_text());old=json.loads((P/f'delivery-v502/验证记录/{t}-build.json').read_text())
 assert r['production_fingerprint']==fp
 assert hashlib.sha256((S/'artifacts'/r['file']).read_bytes()).hexdigest()==r['sha256']
 identical=r['sha256']==old['sha256']
 if t!='dongle_b':assert identical,t
 assert (S/f'artifacts/{t}.dts').read_bytes()==(P/f'delivery-v502/验证记录/{t}.dts').read_bytes(),t
 def conf(p):return dict(l.split('=',1) for l in p.read_text().splitlines() if l.startswith('CONFIG_') and '=' in l)
 c=conf(S/f'artifacts/{t}.config');prior=conf(P/f'delivery-v502/验证记录/{t}.config')
 diff={n:[prior.get(n),c.get(n)] for n in c.keys()|prior.keys() if prior.get(n)!=c.get(n)}
 assert diff==({'CONFIG_BT_SCAN_WITH_IDENTITY':[None,'y']} if t=='dongle_b' else {}),(t,diff)
 assert r.get('ram_bytes')==old.get('ram_bytes'),t
 rows[t]={'UF2_byte_identical_to_v502':identical,'sha256':r['sha256'],'DTS_unchanged':True,'config_changes':diff,'ram_bytes':r.get('ram_bytes')}
 if t.startswith('dongle_'):
  assert c.get('CONFIG_ZMK_SLEEP')!='y' and c.get('CONFIG_ZMK_DISPLAY_BLANK_ON_IDLE')!='y'
  obj=next((W/f'build-{t}').rglob('wpm_meter.c.obj'))
  with obj.open('rb') as f:
   syms=ELFFile(f).get_section_by_name('.symtab');undefined={x.name for x in syms.iter_symbols() if x['st_shndx']=='SHN_UNDEF'}
   assert {'zmk_display_work_q','k_work_schedule_for_queue'}<=undefined and 'k_sys_work_q' not in undefined
assert 'CONFIG_BT_SCAN_WITH_IDENTITY=y' in (S/'artifacts/dongle_b.config').read_text()
ui=(S/'src/xiao147_ui.c').read_text();header=(S/'src/xiao147_ui.h').read_text()
assert 'PAGE_SETTINGS' not in header+ui and 'local_battery' not in ui
assert 'return false;' in ui and ',100))backlight_applied=true;' in ui
report={'passed':True,'production_fingerprint':fp,'previous_commit':previous,'hardware_tested':False,'changed_production_files':changed,'targets':rows,'scope':'Actual UF2 equality, compiled config/DTS, ARM WPM imports and source scope. Physical BLE discovery and screen appearance still require user testing.'}
(V/'xiao147-v503-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
